# Remotion Bangla Text Video

16:9 Full HD motion-text video using your uploaded WAV audio.

## Run
1. Install Node.js 20 or newer.
2. Extract this ZIP and open a terminal in the project folder.
3. Run `npm install`
4. Preview: `npm start`
5. Render MP4: `npm run render`

The output will be `out/video.mp4`.

## Important subtitle note
The uploaded audio is included and its duration is about 20.56 seconds. I could not reliably transcribe the speech here, so the Bengali captions in `src/Video.tsx` are editable placeholders, not a verified transcript. Replace each `text` and its `start` / `end` times in the `subtitles` array with the actual Bengali words and timing.

If your audio duration changes, update `durationInFrames` in `src/Root.tsx` to `Math.ceil(seconds * 30)` using the audio's duration in seconds, and update the final timing in `src/Video.tsx`.
