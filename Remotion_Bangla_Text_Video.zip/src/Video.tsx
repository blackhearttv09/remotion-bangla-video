import React from 'react';
import {
  AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig,
  interpolate, spring
} from 'remotion';

// Audio length: 20.56 seconds. At 30 FPS, 617 frames.
// IMPORTANT: Replace the sample Bengali subtitle lines and timings below
// with the exact transcript of your audio for accurate word-for-word subtitles.
const subtitles = [
  {start: 0, end: 4.5, text: 'এখানে প্রথম বাংলা সাবটাইটেল লিখুন'},
  {start: 4.5, end: 9.0, text: 'এখানে দ্বিতীয় বাংলা সাবটাইটেল লিখুন'},
  {start: 9.0, end: 13.5, text: 'এখানে তৃতীয় বাংলা সাবটাইটেল লিখুন'},
  {start: 13.5, end: 17.5, text: 'এখানে চতুর্থ বাংলা সাবটাইটেল লিখুন'},
  {start: 17.5, end: 20.56, text: 'এখানে শেষ বাংলা সাবটাইটেল লিখুন'}
];

export const BanglaTextVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const seconds = frame / fps;
  const active = subtitles.find((s) => seconds >= s.start && seconds < s.end);
  const index = Math.max(0, subtitles.findIndex((s) => s === active));
  const enter = spring({frame: frame - Math.round((active?.start ?? 0) * fps), fps, config: {damping: 16, stiffness: 110}});
  const opacity = interpolate(frame, [0, 18, 600, 617], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const titleOpacity = interpolate(frame, [0, 22, 95, 120], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  return (
    <AbsoluteFill style={{background: 'linear-gradient(135deg, #07152d 0%, #102b52 52%, #07101f 100%)', color: 'white', fontFamily: '"Noto Sans Bengali", "Nirmala UI", sans-serif', overflow: 'hidden'}}>
      <Audio src={staticFile('audio.wav')} />
      <AbsoluteFill style={{opacity: 0.22, backgroundImage: 'radial-gradient(circle at 20% 20%, #00d5ff 0, transparent 26%), radial-gradient(circle at 80% 75%, #7b2cff 0, transparent 28%)'}} />
      <div style={{position: 'absolute', left: 100, top: 80, width: 120, height: 8, borderRadius: 10, background: '#42e8ff'}} />
      <div style={{position: 'absolute', right: 100, bottom: 90, width: 170, height: 8, borderRadius: 10, background: '#9c73ff'}} />
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', padding: 130, opacity}}>
        <div style={{fontSize: 28, letterSpacing: 8, color: '#7eeeff', fontWeight: 700, marginBottom: 36, opacity: titleOpacity}}>
          AUDIO • MOTION TEXT
        </div>
        <div key={index} style={{
          maxWidth: 1500, textAlign: 'center', fontSize: 66, lineHeight: 1.5,
          fontWeight: 800, padding: '30px 48px', borderRadius: 28,
          background: 'rgba(3, 12, 30, 0.72)', border: '2px solid rgba(105, 222, 255, 0.65)',
          boxShadow: '0 20px 70px rgba(0,0,0,.35)',
          transform: `translateY(${interpolate(enter, [0, 1], [35, 0])}px) scale(${interpolate(enter, [0, 1], [0.94, 1])})`
        }}>
          {active?.text ?? ''}
        </div>
        <div style={{position: 'absolute', bottom: 55, fontSize: 20, color: 'rgba(255,255,255,.62)', letterSpacing: 4}}>
          BANGLA AUDIO VISUALIZER
        </div>
      </AbsoluteFill>
      <AbsoluteFill style={{justifyContent: 'flex-end', padding: '0 100px 28px'}}>
        <div style={{height: 5, background: 'rgba(255,255,255,.18)', borderRadius: 8, overflow: 'hidden'}}>
          <div style={{height: '100%', width: `${(frame / 617) * 100}%`, background: '#42e8ff'}} />
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};