import React from 'react';
import {Composition} from 'remotion';
import {BanglaTextVideo} from './Video';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="BanglaTextVideo"
    component={BanglaTextVideo}
    durationInFrames={617}
    fps={30}
    width={1920}
    height={1080}
    defaultProps={{}}
  />
);